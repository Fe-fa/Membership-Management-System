﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClubManagement.Entities.GeneralMeetings
{
    [Table("General_meeting")]
    public class GeneralMeeting
    {
        [Column("general_meeting_id")]
        [Key]
        public long GeneralMeetingId { get; set; }

        [Column("meeting_type")]
        [Required]
        public string MeetingType { get; set; }

        [Column("meeting_date")]
        public DateOnly MeetingDate { get; set; }

        [Column("notice_sent_date")]
        public DateOnly? NoticeSentDate { get; set; }

        [Column("notice_method")]
        public string? NoticeMethod { get; set; }

        [Column("quorum_required")]
        public int QuorumRequired { get; set; }

        [Column("quorum_met_flag")]
        public bool QuorumMetFlag { get; set; }

        [Column("status")]
        [Required]
        public string Status { get; set; } = "SCHEDULED";

        [Column("adjourned_from_meeting_id")]
        public long? AdjournedFromMeetingId { get; set; }

        [Column("minutes_url")]
        public string? MinutesUrl { get; set; }

        [Column("chairman_profile_id")]
        public long? ChairmanProfileId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; }

        [Column("created_by_user_id")]
        public long? CreatedByUserId { get; set; }

        [Column("updated_by_user_id")]
        public long? UpdatedByUserId { get; set; }

        public virtual GeneralMeeting? AdjournedFrom { get; set; }

        public virtual MProfile? Chairman { get; set; }

        public virtual ICollection<GeneralMeeting> GeneralMeetings { get; set; } = new HashSet<GeneralMeeting>();

        public virtual ICollection<MeetingAgendaItem> MeetingAgendaItems { get; set; } = new HashSet<MeetingAgendaItem>();

        public virtual ICollection<Proxy> Proxies { get; set; } = new HashSet<Proxy>();

        public virtual ICollection<MemberVote> MemberVotes { get; set; } = new HashSet<MemberVote>();

    }
}

