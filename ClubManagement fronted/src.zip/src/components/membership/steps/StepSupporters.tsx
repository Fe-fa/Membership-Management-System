﻿import { memo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Check, Loader2, Search, ShieldCheck, X } from "lucide-react";

import { searchEligibleMembers, type EligibleMember } from "@/services/membership/members";
import { formatKenyaDateShort } from "@/utils/kenyaDate";
import type { ApplicationDraft } from "@/services/membership/schema";
import type { ErrorMap } from "@/services/membership/useApplication";

type Value = ApplicationDraft["supporters"];
type Role = "proposer" | "seconder";
type SupporterDraft = Record<string, unknown>;

function MemberPicker({
  role,
  value,
  excludeProfileId,
  applicationId,
  error,
  onSelect,
  onClear,
}: {
  role: Role;
  value: SupporterDraft;
  excludeProfileId?: string | undefined;
  applicationId?: string | number | null | undefined;
  error?: string | undefined;
  onSelect: (member: EligibleMember) => void;
  onClear: () => void;
}) {
  const [search, setSearch] = useState("");
  const selectedId = String(value["memberProfileId"] ?? "");
  const term = search.trim();
  const { data: members = [], isFetching } = useQuery({
    queryKey: ["members", "eligible", "exact", term, applicationId ?? "none"],
    queryFn: () => searchEligibleMembers(term, applicationId),
    enabled: !selectedId && term.length >= 3,
    staleTime: 60_000,
  });
  const visible = members.filter((member) => member.profileId !== excludeProfileId);
  const memberSince = String(value["joinedDate"] ?? "");
  const memberSinceLabel = memberSince
    ? formatKenyaDateShort(memberSince)
    : value["yearOfJoining"]
      ? String(value["yearOfJoining"])
      : "";

  if (selectedId)
    return (
      <div className="rounded-lg border border-success/40 bg-success/10 p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2 text-sm">
            <ShieldCheck className="mt-0.5 size-4 shrink-0 text-success" />
            <div>
              <p className="font-medium text-foreground">{String(value["membershipNo"] ?? "")}</p>
              <p className="text-muted-foreground">{String(value["name"] ?? "")}</p>
              {memberSinceLabel ? (
                <p className="text-muted-foreground">Member since {memberSinceLabel}</p>
              ) : null}
            </div>
          </div>
          <button
            type="button"
            onClick={onClear}
            className="inline-flex items-center gap-1 rounded-md border border-border bg-background px-2 py-1 text-xs font-medium text-muted-foreground hover:text-foreground"
          >
            <X className="size-3" /> Change
          </button>
        </div>
      </div>
    );

  return (
    <div className="space-y-2">
      <label className="text-xs font-semibold tracking-wide uppercase text-muted-foreground">
        Enter {role} membership no. <span className="text-destructive">*</span>
      </label>
      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="e.g. AC-0001"
          autoComplete="off"
          inputMode="text"
          className="w-full rounded-md border border-input bg-background py-2 pr-3 pl-9 text-sm outline-none focus:ring-2 focus:ring-ring"
        />
        {isFetching && (
          <Loader2 className="absolute top-1/2 right-3 size-4 -translate-y-1/2 animate-spin text-muted-foreground" />
        )}
      </div>
      {term.length > 0 && term.length < 3 ? (
        <p className="text-xs text-muted-foreground">Enter the full membership number.</p>
      ) : null}
      <ul className="max-h-64 divide-y divide-border overflow-auto rounded-md border border-border">
        {term.length < 3 ? (
          <li className="p-3 text-sm text-muted-foreground">
            Search by the exact membership number only.
          </li>
        ) : !visible.length && !isFetching ? (
          <li className="p-3 text-sm text-muted-foreground">
            No member found for this membership number.
          </li>
        ) : (
          visible.map((member) => {
            const canSelect = member.eligible;
            const since = member.joinedDate
              ? formatKenyaDateShort(member.joinedDate)
              : member.yearOfJoining
                ? String(member.yearOfJoining)
                : "";
            return (
              <li key={member.profileId}>
                <button
                  type="button"
                  disabled={!canSelect}
                  onClick={() => {
                    if (canSelect) onSelect(member);
                  }}
                  className={
                    canSelect
                      ? "flex w-full items-center justify-between gap-3 p-3 text-left text-sm hover:bg-secondary"
                      : "flex w-full cursor-not-allowed items-start justify-between gap-3 p-3 text-left text-sm opacity-80"
                  }
                >
                  <span>
                    <span className="block font-medium text-foreground">{member.membershipNo}</span>
                    <span className="block text-muted-foreground">
                      {member.fullName} · {member.membershipType}
                      {since ? ` · since ${since}` : ""}
                    </span>
                    {!canSelect && member.ineligibleReason ? (
                      <span className="mt-1 flex items-start gap-1 text-xs text-destructive">
                        <AlertTriangle className="mt-0.5 size-3 shrink-0" />
                        {member.ineligibleReason}
                      </span>
                    ) : null}
                  </span>
                  {canSelect ? <Check className="size-4 text-muted-foreground" /> : null}
                </button>
              </li>
            );
          })
        )}
      </ul>
      {error && (
        <p className="flex items-center gap-1 text-xs text-destructive">
          <AlertTriangle className="size-3" /> {error}
        </p>
      )}
    </div>
  );
}

function SupporterSelector({
  role,
  value,
  error,
  excludeProfileId,
  applicationId,
  onChange,
}: {
  role: Role;
  value: SupporterDraft;
  error?: string | undefined;
  excludeProfileId?: string | undefined;
  applicationId?: string | number | null | undefined;
  onChange: (patch: Partial<SupporterDraft>) => void;
}) {
  const label = role === "proposer" ? "Proposer" : "Seconder";
  return (
    <section className="surface-card space-y-4 p-5">
      <div>
        <h3 className="text-lg">{label}</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Enter the member&apos;s full membership number to find that person only.
        </p>
      </div>
      <MemberPicker
        role={role}
        value={value}
        excludeProfileId={excludeProfileId}
        applicationId={applicationId}
        error={error}
        onSelect={(member) =>
          onChange({
            memberProfileId: member.profileId,
            membershipNo: member.membershipNo,
            name: member.fullName,
            email: member.email,
            phone: member.phone,
            yearOfJoining: String(member.yearOfJoining),
            joinedDate: member.joinedDate ?? "",
          })
        }
        onClear={() =>
          onChange({
            memberProfileId: "",
            membershipNo: "",
            name: "",
            email: "",
            phone: "",
            yearOfJoining: "",
            joinedDate: "",
          })
        }
      />
    </section>
  );
}

export const StepSupporters = memo(function StepSupporters({
  value,
  errors,
  onChange,
  applicationId,
}: {
  value: Value;
  errors: ErrorMap;
  onChange: (patch: Partial<Value>) => void;
  applicationId?: string | number | null;
}) {
  const proposer = value.proposer as SupporterDraft;
  const seconder = value.seconder as SupporterDraft;
  return (
    <div className="space-y-6">
      <SupporterSelector
        role="proposer"
        value={proposer}
        error={errors["proposer.memberProfileId"]}
        excludeProfileId={String(seconder["memberProfileId"] ?? "") || undefined}
        applicationId={applicationId}
        onChange={(patch) =>
          onChange({ proposer: { ...value.proposer, ...patch } as Value["proposer"] })
        }
      />
      <SupporterSelector
        role="seconder"
        value={seconder}
        error={errors["seconder.memberProfileId"]}
        excludeProfileId={String(proposer["memberProfileId"] ?? "") || undefined}
        applicationId={applicationId}
        onChange={(patch) =>
          onChange({ seconder: { ...value.seconder, ...patch } as Value["seconder"] })
        }
      />
    </div>
  );
});
