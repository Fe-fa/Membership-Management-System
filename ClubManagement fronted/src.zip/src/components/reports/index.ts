/** Report widgets (future). */
export {};
