﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClubManagement.Entities.Committee
{
    [Table("Committee")]
    public class Committee
    {
        [Column("committee_id")]
        [Key]
        public long CommitteeId { get; set; }

        [Column("committee_name")]
        [Required]
        public string CommitteeName { get; set; }

        [Column("term_start")]
        public DateOnly? TermStart { get; set; }

        [Column("term_end")]
        public DateOnly? TermEnd { get; set; }

        [Column("is_active")]
        public bool IsActive { get; set; } = true;

        [Column("created_at")]
        public DateTime CreatedAt { get; set; }

        [Column("created_by_user_id")]
        public long? CreatedByUserId { get; set; }

        [Column("updated_by_user_id")]
        public long? UpdatedByUserId { get; set; }

        public virtual ICollection<CommitteeMember> CommitteeMembers { get; set; } = new HashSet<CommitteeMember>();

        public virtual ICollection<CommitteeMeeting> CommitteeMeetings { get; set; } = new HashSet<CommitteeMeeting>();

    }
}

