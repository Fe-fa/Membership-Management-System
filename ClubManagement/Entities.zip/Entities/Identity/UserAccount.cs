﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ClubManagement.Entities.Identity
{
    [Table("User_account")]
    public class UserAccount
    {
        [Column("user_account_id")]
        [Key]
        public long UserAccountId { get; set; }

        [Column("profile_id")]
        public long ProfileId { get; set; }

        [Column("username")]
        [Required]
        public string Username { get; set; }

        [Column("password_hash")]
        [Required]
        public string PasswordHash { get; set; }

        [Column("is_active")]
        public bool IsActive { get; set; } = true;

        [Column("last_login_at")]
        public DateTime? LastLoginAt { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; }

        [Column("created_by_user_id")]
        public long? CreatedByUserId { get; set; }

        [Column("updated_by_user_id")]
        public long? UpdatedByUserId { get; set; }

        public virtual MProfile Profile { get; set; } = null!;

        public virtual ICollection<UserRole> UserRoles { get; set; } = new HashSet<UserRole>();

    }
}
