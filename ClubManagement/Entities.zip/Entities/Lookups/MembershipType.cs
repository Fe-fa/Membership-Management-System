﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ClubManagement.Entities.MembershipAccount;

namespace ClubManagement.Entities.Lookups
{
    [Table("Membership_type")]
    public class MembershipType
    {
        [Column("membership_type_id")]
        [Key]
        public long MembershipTypeId { get; set; }

        [Column("code")]
        [Required]
        public string Code { get; set; }

        [Column("name")]
        [Required]
        public string Name { get; set; }

        [Column("description")]
        public string? Description { get; set; }

        [Column("sort_order")]
        public int SortOrder { get; set; }

        [Column("is_active")]
        public bool IsActive { get; set; } = true;

        [Column("can_vote")]
        public bool CanVote { get; set; }

        [Column("can_run_for_office")]
        public bool CanRunForOffice { get; set; }

        [Column("reciprocation_allowed")]
        public bool ReciprocationAllowed { get; set; }

        [Column("can_introduce_guests")]
        public bool CanIntroduceGuests { get; set; }

        [Column("max_duration_days")]
        public int? MaxDurationDays { get; set; }

        [Column("is_permanent")]
        public bool IsPermanent { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; }

        [Column("updated_by_user_id")]
        public long? UpdatedByUserId { get; set; }

        public virtual ICollection<MAccount> MAccounts { get; set; } = new HashSet<MAccount>();

    }
}
